package com.dirror.music.data

@Deprecated("过时")
data class LyricData(
    val startTime: Int, // 单句歌词开始时间
    val content: String // 单行
)