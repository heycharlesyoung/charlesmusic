package com.dirror.music.foyou.sentence

data class SentenceData(
    val text: String,
    val author: String,
    val source: String
)