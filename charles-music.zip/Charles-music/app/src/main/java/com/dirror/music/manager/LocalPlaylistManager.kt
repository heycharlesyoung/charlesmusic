package com.dirror.music.manager

import com.dirror.music.manager.interfaces.LocalPlaylistManagerInterface

class LocalPlaylistManager: LocalPlaylistManagerInterface {

    override fun addNewPlaylist() {
        TODO("Not yet implemented")
    }

}