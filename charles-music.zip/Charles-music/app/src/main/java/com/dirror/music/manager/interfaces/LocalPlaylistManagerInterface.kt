package com.dirror.music.manager.interfaces

interface LocalPlaylistManagerInterface {

    /**
     * 添加新本地歌单
     */
    fun addNewPlaylist()

}