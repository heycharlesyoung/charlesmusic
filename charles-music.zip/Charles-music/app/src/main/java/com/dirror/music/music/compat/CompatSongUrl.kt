package com.dirror.music.music.compat

/**
 * 辅助 URL
 */
object CompatSongUrl {

    // https://www.hifini.com/get_music.php?key=vsaqN6+Mgw21bh3eX9do74LwiTAWzi8z3bvbblKhswaMa0e96KdVvMzP+zw5USwwKreOD0J/MXEKwZFpx06ODlE
}