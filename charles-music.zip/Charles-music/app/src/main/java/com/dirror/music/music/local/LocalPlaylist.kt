package com.dirror.music.music.local

object LocalPlaylist {

}