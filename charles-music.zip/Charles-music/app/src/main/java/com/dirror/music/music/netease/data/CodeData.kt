package com.dirror.music.music.netease.data

data class CodeData(
    val code: Int = 400
)
