package com.dirror.music.music.standard

import com.dirror.music.music.standard.data.StandardSongData

object SongInfo {

    fun getSongInfo(songData: StandardSongData) {



    }

}