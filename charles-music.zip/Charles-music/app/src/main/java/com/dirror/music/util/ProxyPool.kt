package com.dirror.music.util

/**
 * ip 代理池
 * 解决网易云封 ip 导致请求出现 -460 的问题
 */
object ProxyPool {

}